# Task 3 (School Registration Form)

print("\tWELCOME TO IDEAL COLLEGE")
print("==============================================")
print("\tSTUDENT REGISTRATION FORM")
print("==============================================")
print("Please provide the following details to complete your registration.\n")

# Student details
student_name = input("Enter your full name: ")
student_class = input("Enter the class you are admitted in (e.g., SS1, SS2, JSS3): ")
state_of_origin = input("Enter your state of origin: ")

# Output result
print("\n Registration Successful!")
print("----------------------------------------------")
print("Student " + student_name + " is in " + student_class + " and is from " + state_of_origin + " State.")
print("----------------------------------------------")
print(" Welcome to Ideal College, " + student_name + "! We’re glad to have you.\n")
