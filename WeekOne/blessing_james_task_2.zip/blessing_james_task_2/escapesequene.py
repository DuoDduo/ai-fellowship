# NIGERIAN DISH HIGHLIGHT
# ==============================
# Enter the name of a Nigerian dish: Amala
# Enter the state it is popular in: Oyo

# Here’s what we found about this delicious dish:
# Dish: Amala
#     Popular in: Oyo State

# Fun Fact: Amala is one of Nigeria's beloved meals, enjoyed by locals and visitors alike!

print("==================NIGERIAN DISH HIGHLIGHT====================\n")
dish=input("Enter the name of a Nigerian dish: ")
state=input("Enter the state it is popular in: ")
print(f"Here's what we found about the delicious dish: {dish}, that is popular in {state}. \n It is one of Nigeria's beloved meal, enjoyed by locals and visitors alike, It really gained popularity in \t {state}  state" )

