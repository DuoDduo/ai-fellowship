print("Welcome to RaizaHub Mobile Service")
print("Your Trusted Naija USSD Platform!\n")

ussd_code = input("Dial your USSD code to proceed (e.g., *123#): ")

menu = "Please select an option:\n1. Check Data Balance\n2. Check Mifi Balance\n3. Check Router Balance"
print("\n" + menu)

choice = input("\nEnter your choice (1, 2, or 3): ")
print(f"You selected option {choice}")
print("Your data balance is 25.00GB")
print("Thank you for choosing RaizaHub. Stay connected, stay empowered!")
print("Need help? Call 0800-RAIZAHUB or visit www.raizahub.com\n")