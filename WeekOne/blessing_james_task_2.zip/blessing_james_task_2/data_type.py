# =====================================
#    PERSONAL INFO COLLECTOR 
# =====================================
# Enter your full name: Tunde Adesanya
# Enter your age (in years): 21
# Enter your height (in meters): 1.80





print("==========================\n PERSONAL INFO COLLECTOR \n===========================")

name=input("Enter your Full name: ")
age=int(input("Enter your age: "))
height= float(input("Enter your height (in metres) : "))

print(f"{name} is {age} years old and is {height} meters tall. Thanks for filling the form, {name}.")