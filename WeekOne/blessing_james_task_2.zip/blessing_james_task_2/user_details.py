# Task!
name = input("Welcome to Spice Haven, Please enter your name: ")
age= int(input("Please enter your age: "))
print(f"Welcome to Spice Haven,{name}! You are {age} years young and ready for a delicious adventure.\n")